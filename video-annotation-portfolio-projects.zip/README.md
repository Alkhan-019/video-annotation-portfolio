# Video Annotation Portfolio

This repository contains practice/demo projects demonstrating video annotation, object detection, action recognition, and annotation quality review.

## Projects

1. **Object Detection in Video** — bounding-box labeling and structured annotations.
2. **Video Action Recognition** — temporal action labeling across frame ranges.
3. **Annotation Quality Review** — identifying and correcting an example annotation issue.

## Skills demonstrated

- Video frame analysis
- Object detection and labeling
- Bounding-box annotation
- Action/event classification
- Temporal reasoning
- Annotation quality assurance
- Structured data labeling
- Following annotation guidelines

## Important note

All examples in this repository are synthetic portfolio demonstrations created for practice. They do not contain confidential client or employer data and should not be presented as paid client work.
