# Project 2 — Video Action Recognition

**Type:** Practice/demo project  
**Goal:** Demonstrate temporal labeling of actions across a video sequence.

## Task
A hypothetical video sequence is divided into action segments. Each segment receives one consistent action label.

### Labels used
- `walking`
- `stopping`
- `turning`

### Annotation approach
1. Review the sequence frame by frame.
2. Identify the start and end of each action.
3. Assign the appropriate action label.
4. Check that adjacent segments do not overlap or leave unexplained gaps.

## Sample output
See `action_timeline_demo.png`.

> This is a synthetic portfolio demonstration created for practice. It does not represent client or employer data.
