# Project 1 — Object Detection in Video

**Type:** Practice/demo project  
**Goal:** Demonstrate frame-level object detection and bounding-box labeling.

## Annotation task
A sample video frame was reviewed and visible objects were labeled using bounding boxes.

### Labels
- `car`
- `person`

### Annotation considerations
- Identify the full visible object.
- Keep the bounding box close to the object's visible extent.
- Use the same label consistently across frames.
- Record frame-level annotations in structured JSON.

## Sample output
See `annotated_frame_demo.png`.

## Data format
`annotations.json` contains a simple frame/label/bounding-box representation.

> This is a synthetic portfolio demonstration created for practice. It does not represent client or employer data.
