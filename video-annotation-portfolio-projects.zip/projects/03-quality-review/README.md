# Project 3 — Video Annotation Quality Review

**Type:** Practice/demo project  
**Goal:** Demonstrate quality assurance for video annotation.

## Review task
An example annotation was checked against a simple quality rule: the bounding box should closely follow the visible object.

### Issue identified
The original bounding box extended beyond the visible object.

### Corrective action
The box was tightened to better match the object.

### QA skills demonstrated
- Attention to detail
- Annotation consistency
- Error identification
- Applying annotation guidelines
- Recording corrections

## Sample output
See `quality_review_demo.png`.

> This is a synthetic portfolio demonstration created for practice. It does not represent client or employer data.
